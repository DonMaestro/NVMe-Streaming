# 10Gb Ethernet [empty]

Links

[https://www.intel.com/content/www/us/en/products/details/fpga/intellectual-property/interface-protocols/1g-10g.html](https://www.intel.com/content/www/us/en/products/details/fpga/intellectual-property/interface-protocols/1g-10g.html)