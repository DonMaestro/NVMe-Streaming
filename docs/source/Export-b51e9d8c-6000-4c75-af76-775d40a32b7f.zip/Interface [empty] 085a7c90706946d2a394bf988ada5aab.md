# Interface [empty]

## **Avalon-MM**

Links

[Avalon® Interface Specifications](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&ved=2ahUKEwiVjueu9Yr8AhVDmosKHV3CAHkQFnoECA0QAQ&url=https%3A%2F%2Fwww.intel.com%2Fcontent%2Fdam%2Fwww%2Fprogrammable%2Fus%2Fen%2Fpdfs%2Fliterature%2Fmanual%2Fmnl_avalon_spec.pdf&usg=AOvVaw0KRH8z7jYf5e4cCs0C4vul)

[https://en.wikipedia.org/wiki/Advanced_eXtensible_Interface](https://en.wikipedia.org/wiki/Advanced_eXtensible_Interface)

[Building a basic AXI Master](https://zipcpu.com/blog/2020/03/23/wbm2axisp.html)

Аналіз відомих технічних рішень побудови об’єкту розробки на основі проведеного патентного пошуку